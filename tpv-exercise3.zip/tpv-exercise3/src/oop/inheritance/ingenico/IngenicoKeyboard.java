package oop.inheritance.ingenico;

public class IngenicoKeyboard {

    /**
     * @return key pressed
     */
    public String get() {
        return "Key pressed";
    }
}
