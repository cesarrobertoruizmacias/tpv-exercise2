package oop.inheritance.data;

public enum SupportedTerminal {
    INGENICO,
    VERIFONE
}
