package oop.inheritance.data;

public enum EntryMode {
    INSERTED,
    SWIPED,
    MANUAL
}
