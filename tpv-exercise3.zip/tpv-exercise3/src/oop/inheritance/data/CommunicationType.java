package oop.inheritance.data;

public enum CommunicationType {
    GPS,
    MODEM,
    ETHERNET
}
