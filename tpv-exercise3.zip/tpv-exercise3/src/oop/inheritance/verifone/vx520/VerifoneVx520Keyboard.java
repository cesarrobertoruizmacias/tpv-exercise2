package oop.inheritance.verifone.vx520;

public class VerifoneVx520Keyboard {

    public String get(){
        return "Key pressed";
    }
}
