package oop.inheritance.verifone.v240m;

public class VerifoneV240mKeyboard {

    public String get(){
        return "Key pressed";
    }
}
