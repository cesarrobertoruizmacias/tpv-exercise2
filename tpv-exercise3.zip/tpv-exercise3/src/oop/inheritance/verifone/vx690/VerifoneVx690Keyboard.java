package oop.inheritance.verifone.vx690;

public class VerifoneVx690Keyboard {

    public String get(){
        return "Key pressed";
    }
}
